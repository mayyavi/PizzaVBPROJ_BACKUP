﻿Imports System.Data.SqlClient

Public Class admin
    Public connectionString As String = "Data Source=DESKTOP-G9C6I8O\SQLEXPRESS;Initial Catalog=pizzadb;Integrated Security=True;"

    Private Sub admin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadUserData()
        LoadCustomerData()
    End Sub

    Private Sub LoadCustomerData()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim query As String = "SELECT * FROM Customer"
                    Using command As New SqlCommand(query, connection)
                        Using adapter As New SqlDataAdapter(command)
                            Dim customerTable As New DataTable()
                            adapter.Fill(customerTable)
                            DataGridView2.DataSource = customerTable

                            ' Use SqlCommandBuilder to automatically generate the UpdateCommand
                            Dim builder As New SqlCommandBuilder(adapter)
                        End Using
                    End Using
                Else
                    MessageBox.Show("Unable to open database connection.")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub LoadUserData()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim query As String = "SELECT * FROM Users"
                    Using command As New SqlCommand(query, connection)
                        Using adapter As New SqlDataAdapter(command)
                            Dim userTable As New DataTable()
                            adapter.Fill(userTable)
                            DataGridView1.DataSource = userTable

                            ' Use SqlCommandBuilder to automatically generate the UpdateCommand
                            Dim builder As New SqlCommandBuilder(adapter)
                        End Using
                    End Using
                Else
                    MessageBox.Show("Unable to open database connection.")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim userTable As DataTable = CType(DataGridView1.DataSource, DataTable)
                    Using adapter As New SqlDataAdapter("SELECT * FROM Users", connection)
                        ' Use SqlCommandBuilder to automatically generate the UpdateCommand
                        Dim builder As New SqlCommandBuilder(adapter)
                        adapter.Update(userTable)
                    End Using

                    MessageBox.Show("Data updated successfully.")
                Else
                    MessageBox.Show("Unable to open database connection.")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim customerTable As DataTable = CType(DataGridView2.DataSource, DataTable)
                    Using adapter As New SqlDataAdapter("SELECT * FROM Customer", connection)
                        ' Use SqlCommandBuilder to automatically generate the UpdateCommand
                        Dim builder As New SqlCommandBuilder(adapter)
                        adapter.Update(customerTable)
                    End Using

                    MessageBox.Show("Data updated successfully.")
                Else
                    MessageBox.Show("Unable to open database connection.")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        login.Show()
        Me.Hide()
    End Sub
End Class
