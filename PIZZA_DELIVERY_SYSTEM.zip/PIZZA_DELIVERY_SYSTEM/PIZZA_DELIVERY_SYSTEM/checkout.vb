﻿Public Class checkout

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If dashboard.checkCustomer() = False Then Exit Sub
        dashboard.prtDeliveryNote.Print()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        dashboard.Show()
        Me.Hide()
    End Sub
End Class