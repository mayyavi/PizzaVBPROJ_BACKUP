﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        txtTel = New TextBox()
        cmdContinue = New Button()
        Panel1 = New Panel()
        Button1 = New Button()
        pnlLeft = New Panel()
        txtOrder = New TextBox()
        Label9 = New Label()
        cmdSave = New Button()
        txtForename = New TextBox()
        txtSurname = New TextBox()
        txtAddress01 = New TextBox()
        txtAddress02 = New TextBox()
        txtTown = New TextBox()
        txtPostcode = New TextBox()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        pnlRight = New Panel()
        cmdClear = New Button()
        cmdPrint = New Button()
        lblOderTotal = New Label()
        lblDeliveryCharge = New Label()
        lblOderValue = New Label()
        Label21 = New Label()
        Label20 = New Label()
        Label19 = New Label()
        pnlDrinks = New Panel()
        nudDrk03 = New NumericUpDown()
        nudDrk02 = New NumericUpDown()
        nudDrk01 = New NumericUpDown()
        nudDrk00 = New NumericUpDown()
        Label18 = New Label()
        Label17 = New Label()
        Label16 = New Label()
        Label15 = New Label()
        Label14 = New Label()
        Label13 = New Label()
        cmdAddItem = New Button()
        pnlExtras = New Panel()
        chkExt03 = New CheckBox()
        chkExt02 = New CheckBox()
        chkExt01 = New CheckBox()
        chkExt00 = New CheckBox()
        Label12 = New Label()
        pnlBase = New Panel()
        radbas02 = New RadioButton()
        radBas01 = New RadioButton()
        radBas00 = New RadioButton()
        Label11 = New Label()
        pnlTopping = New Panel()
        Label10 = New Label()
        radTop02 = New RadioButton()
        radTop01 = New RadioButton()
        radTop00 = New RadioButton()
        prtContinuation = New Printing.PrintDocument()
        prtDeliveryNote = New Printing.PrintDocument()
        Panel1.SuspendLayout()
        pnlLeft.SuspendLayout()
        pnlRight.SuspendLayout()
        pnlDrinks.SuspendLayout()
        CType(nudDrk03, ComponentModel.ISupportInitialize).BeginInit()
        CType(nudDrk02, ComponentModel.ISupportInitialize).BeginInit()
        CType(nudDrk01, ComponentModel.ISupportInitialize).BeginInit()
        CType(nudDrk00, ComponentModel.ISupportInitialize).BeginInit()
        pnlExtras.SuspendLayout()
        pnlBase.SuspendLayout()
        pnlTopping.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Showcard Gothic", 22.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(601, 19)
        Label1.Name = "Label1"
        Label1.Size = New Size(265, 46)
        Label1.TabIndex = 0
        Label1.Text = "pizza order "
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label2.Location = New Point(445, 107)
        Label2.Name = "Label2"
        Label2.Size = New Size(106, 28)
        Label2.TabIndex = 1
        Label2.Text = "Phone no."
        ' 
        ' txtTel
        ' 
        txtTel.Location = New Point(557, 111)
        txtTel.Name = "txtTel"
        txtTel.Size = New Size(192, 27)
        txtTel.TabIndex = 7
        ' 
        ' cmdContinue
        ' 
        cmdContinue.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        cmdContinue.ForeColor = SystemColors.ActiveCaptionText
        cmdContinue.Location = New Point(772, 101)
        cmdContinue.Name = "cmdContinue"
        cmdContinue.Size = New Size(126, 40)
        cmdContinue.TabIndex = 8
        cmdContinue.Text = "Continue"
        cmdContinue.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(1, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1532, 86)
        Panel1.TabIndex = 9
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Button1.Location = New Point(1363, 19)
        Button1.Name = "Button1"
        Button1.Size = New Size(135, 54)
        Button1.TabIndex = 12
        Button1.Text = "log out"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' pnlLeft
        ' 
        pnlLeft.BackColor = Color.MidnightBlue
        pnlLeft.Controls.Add(txtOrder)
        pnlLeft.Controls.Add(Label9)
        pnlLeft.Controls.Add(cmdSave)
        pnlLeft.Controls.Add(txtForename)
        pnlLeft.Controls.Add(txtSurname)
        pnlLeft.Controls.Add(txtAddress01)
        pnlLeft.Controls.Add(txtAddress02)
        pnlLeft.Controls.Add(txtTown)
        pnlLeft.Controls.Add(txtPostcode)
        pnlLeft.Controls.Add(Label8)
        pnlLeft.Controls.Add(Label7)
        pnlLeft.Controls.Add(Label6)
        pnlLeft.Controls.Add(Label5)
        pnlLeft.Controls.Add(Label4)
        pnlLeft.Controls.Add(Label3)
        pnlLeft.Location = New Point(171, 186)
        pnlLeft.Name = "pnlLeft"
        pnlLeft.Size = New Size(380, 661)
        pnlLeft.TabIndex = 10
        ' 
        ' txtOrder
        ' 
        txtOrder.Location = New Point(38, 472)
        txtOrder.Multiline = True
        txtOrder.Name = "txtOrder"
        txtOrder.ScrollBars = ScrollBars.Vertical
        txtOrder.Size = New Size(301, 157)
        txtOrder.TabIndex = 20
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(22, 415)
        Label9.Name = "Label9"
        Label9.Size = New Size(117, 23)
        Label9.TabIndex = 19
        Label9.Text = "Order Details"
        ' 
        ' cmdSave
        ' 
        cmdSave.BackColor = Color.Yellow
        cmdSave.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        cmdSave.Location = New Point(184, 331)
        cmdSave.Name = "cmdSave"
        cmdSave.Size = New Size(140, 44)
        cmdSave.TabIndex = 18
        cmdSave.Text = "Save Customer"
        cmdSave.UseVisualStyleBackColor = False
        ' 
        ' txtForename
        ' 
        txtForename.Location = New Point(184, 38)
        txtForename.Name = "txtForename"
        txtForename.Size = New Size(125, 27)
        txtForename.TabIndex = 12
        ' 
        ' txtSurname
        ' 
        txtSurname.Location = New Point(184, 85)
        txtSurname.Name = "txtSurname"
        txtSurname.Size = New Size(125, 27)
        txtSurname.TabIndex = 13
        ' 
        ' txtAddress01
        ' 
        txtAddress01.Location = New Point(184, 131)
        txtAddress01.Name = "txtAddress01"
        txtAddress01.Size = New Size(125, 27)
        txtAddress01.TabIndex = 14
        ' 
        ' txtAddress02
        ' 
        txtAddress02.Location = New Point(184, 173)
        txtAddress02.Name = "txtAddress02"
        txtAddress02.Size = New Size(125, 27)
        txtAddress02.TabIndex = 15
        ' 
        ' txtTown
        ' 
        txtTown.Location = New Point(184, 215)
        txtTown.Name = "txtTown"
        txtTown.Size = New Size(125, 27)
        txtTown.TabIndex = 16
        ' 
        ' txtPostcode
        ' 
        txtPostcode.Location = New Point(184, 258)
        txtPostcode.Name = "txtPostcode"
        txtPostcode.Size = New Size(125, 27)
        txtPostcode.TabIndex = 17
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label8.ForeColor = Color.White
        Label8.Location = New Point(22, 262)
        Label8.Name = "Label8"
        Label8.Size = New Size(89, 23)
        Label8.TabIndex = 5
        Label8.Text = "PINCODE "
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label7.ForeColor = Color.White
        Label7.Location = New Point(22, 219)
        Label7.Name = "Label7"
        Label7.Size = New Size(47, 23)
        Label7.TabIndex = 4
        Label7.Text = "City "
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label6.ForeColor = Color.White
        Label6.Location = New Point(22, 173)
        Label6.Name = "Label6"
        Label6.Size = New Size(89, 23)
        Label6.TabIndex = 3
        Label6.Text = "Address 2"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label5.ForeColor = Color.White
        Label5.Location = New Point(22, 135)
        Label5.Name = "Label5"
        Label5.Size = New Size(94, 23)
        Label5.TabIndex = 2
        Label5.Text = "Address 1 "
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(22, 89)
        Label4.Name = "Label4"
        Label4.Size = New Size(99, 23)
        Label4.TabIndex = 1
        Label4.Text = "Last Name "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(22, 41)
        Label3.Name = "Label3"
        Label3.Size = New Size(102, 23)
        Label3.TabIndex = 0
        Label3.Text = "First Name "
        ' 
        ' pnlRight
        ' 
        pnlRight.BackColor = SystemColors.ActiveCaption
        pnlRight.Controls.Add(cmdClear)
        pnlRight.Controls.Add(cmdPrint)
        pnlRight.Controls.Add(lblOderTotal)
        pnlRight.Controls.Add(lblDeliveryCharge)
        pnlRight.Controls.Add(lblOderValue)
        pnlRight.Controls.Add(Label21)
        pnlRight.Controls.Add(Label20)
        pnlRight.Controls.Add(Label19)
        pnlRight.Controls.Add(pnlDrinks)
        pnlRight.Controls.Add(cmdAddItem)
        pnlRight.Controls.Add(pnlExtras)
        pnlRight.Controls.Add(pnlBase)
        pnlRight.Controls.Add(pnlTopping)
        pnlRight.Location = New Point(772, 186)
        pnlRight.Name = "pnlRight"
        pnlRight.Size = New Size(696, 661)
        pnlRight.TabIndex = 11
        ' 
        ' cmdClear
        ' 
        cmdClear.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        cmdClear.Location = New Point(71, 597)
        cmdClear.Name = "cmdClear"
        cmdClear.Size = New Size(112, 32)
        cmdClear.TabIndex = 27
        cmdClear.Text = "Clear"
        cmdClear.UseVisualStyleBackColor = True
        ' 
        ' cmdPrint
        ' 
        cmdPrint.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        cmdPrint.Location = New Point(41, 547)
        cmdPrint.Name = "cmdPrint"
        cmdPrint.Size = New Size(194, 40)
        cmdPrint.TabIndex = 26
        cmdPrint.Text = "Make Bill"
        cmdPrint.UseVisualStyleBackColor = True
        ' 
        ' lblOderTotal
        ' 
        lblOderTotal.AutoSize = True
        lblOderTotal.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblOderTotal.Location = New Point(536, 596)
        lblOderTotal.Name = "lblOderTotal"
        lblOderTotal.Size = New Size(73, 23)
        lblOderTotal.TabIndex = 25
        lblOderTotal.Text = "Label22"
        ' 
        ' lblDeliveryCharge
        ' 
        lblDeliveryCharge.AutoSize = True
        lblDeliveryCharge.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblDeliveryCharge.Location = New Point(536, 564)
        lblDeliveryCharge.Name = "lblDeliveryCharge"
        lblDeliveryCharge.Size = New Size(73, 23)
        lblDeliveryCharge.TabIndex = 24
        lblDeliveryCharge.Text = "Label22"
        ' 
        ' lblOderValue
        ' 
        lblOderValue.AutoSize = True
        lblOderValue.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblOderValue.Location = New Point(536, 534)
        lblOderValue.Name = "lblOderValue"
        lblOderValue.Size = New Size(73, 23)
        lblOderValue.TabIndex = 23
        lblOderValue.Text = "Label22"
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Segoe UI", 13F, FontStyle.Bold)
        Label21.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label21.Location = New Point(351, 590)
        Label21.Name = "Label21"
        Label21.Size = New Size(131, 30)
        Label21.TabIndex = 22
        Label21.Text = "Order Total"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Segoe UI", 13F, FontStyle.Bold)
        Label20.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label20.Location = New Point(351, 557)
        Label20.Name = "Label20"
        Label20.Size = New Size(179, 30)
        Label20.TabIndex = 21
        Label20.Text = "Delivery Charge"
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Segoe UI", 13F, FontStyle.Bold)
        Label19.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label19.Location = New Point(351, 527)
        Label19.Name = "Label19"
        Label19.Size = New Size(136, 30)
        Label19.TabIndex = 20
        Label19.Text = "Order Value"
        ' 
        ' pnlDrinks
        ' 
        pnlDrinks.BackColor = SystemColors.ActiveBorder
        pnlDrinks.Controls.Add(nudDrk03)
        pnlDrinks.Controls.Add(nudDrk02)
        pnlDrinks.Controls.Add(nudDrk01)
        pnlDrinks.Controls.Add(nudDrk00)
        pnlDrinks.Controls.Add(Label18)
        pnlDrinks.Controls.Add(Label17)
        pnlDrinks.Controls.Add(Label16)
        pnlDrinks.Controls.Add(Label15)
        pnlDrinks.Controls.Add(Label14)
        pnlDrinks.Controls.Add(Label13)
        pnlDrinks.Location = New Point(19, 272)
        pnlDrinks.Name = "pnlDrinks"
        pnlDrinks.Size = New Size(326, 254)
        pnlDrinks.TabIndex = 4
        ' 
        ' nudDrk03
        ' 
        nudDrk03.Location = New Point(205, 187)
        nudDrk03.Name = "nudDrk03"
        nudDrk03.Size = New Size(100, 27)
        nudDrk03.TabIndex = 21
        ' 
        ' nudDrk02
        ' 
        nudDrk02.Location = New Point(205, 145)
        nudDrk02.Name = "nudDrk02"
        nudDrk02.Size = New Size(100, 27)
        nudDrk02.TabIndex = 20
        ' 
        ' nudDrk01
        ' 
        nudDrk01.Location = New Point(205, 108)
        nudDrk01.Name = "nudDrk01"
        nudDrk01.Size = New Size(100, 27)
        nudDrk01.TabIndex = 19
        ' 
        ' nudDrk00
        ' 
        nudDrk00.Location = New Point(205, 69)
        nudDrk00.Name = "nudDrk00"
        nudDrk00.Size = New Size(100, 27)
        nudDrk00.TabIndex = 18
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Segoe UI", 11F, FontStyle.Bold)
        Label18.ForeColor = SystemColors.ButtonFace
        Label18.Location = New Point(26, 185)
        Label18.Name = "Label18"
        Label18.Size = New Size(138, 25)
        Label18.TabIndex = 17
        Label18.Text = "Mineral Water"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Segoe UI", 11F, FontStyle.Bold)
        Label17.ForeColor = SystemColors.ButtonFace
        Label17.Location = New Point(22, 143)
        Label17.Name = "Label17"
        Label17.Size = New Size(78, 25)
        Label17.TabIndex = 16
        Label17.Text = "Orange"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Segoe UI", 11F, FontStyle.Bold)
        Label16.ForeColor = SystemColors.ButtonFace
        Label16.Location = New Point(22, 110)
        Label16.Name = "Label16"
        Label16.Size = New Size(105, 25)
        Label16.TabIndex = 15
        Label16.Text = "Lemonade"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Segoe UI", 11F, FontStyle.Bold)
        Label15.ForeColor = SystemColors.ButtonFace
        Label15.Location = New Point(22, 67)
        Label15.Name = "Label15"
        Label15.Size = New Size(51, 25)
        Label15.TabIndex = 14
        Label15.Text = "Cola"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 14F, FontStyle.Bold)
        Label14.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label14.Location = New Point(215, 9)
        Label14.Name = "Label14"
        Label14.Size = New Size(69, 32)
        Label14.TabIndex = 13
        Label14.Text = "Qnty"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI", 14F, FontStyle.Bold)
        Label13.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label13.Location = New Point(3, 9)
        Label13.Name = "Label13"
        Label13.Size = New Size(88, 32)
        Label13.TabIndex = 12
        Label13.Text = "Drinks"
        ' 
        ' cmdAddItem
        ' 
        cmdAddItem.BackColor = Color.SeaGreen
        cmdAddItem.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        cmdAddItem.ForeColor = SystemColors.ButtonFace
        cmdAddItem.Location = New Point(248, 215)
        cmdAddItem.Name = "cmdAddItem"
        cmdAddItem.Size = New Size(134, 38)
        cmdAddItem.TabIndex = 3
        cmdAddItem.Text = "Add Item"
        cmdAddItem.UseVisualStyleBackColor = False
        ' 
        ' pnlExtras
        ' 
        pnlExtras.BackColor = Color.Yellow
        pnlExtras.Controls.Add(chkExt03)
        pnlExtras.Controls.Add(chkExt02)
        pnlExtras.Controls.Add(chkExt01)
        pnlExtras.Controls.Add(chkExt00)
        pnlExtras.Controls.Add(Label12)
        pnlExtras.Location = New Point(445, 26)
        pnlExtras.Name = "pnlExtras"
        pnlExtras.Size = New Size(169, 170)
        pnlExtras.TabIndex = 2
        ' 
        ' chkExt03
        ' 
        chkExt03.AutoSize = True
        chkExt03.Font = New Font("Segoe UI", 10F)
        chkExt03.Location = New Point(12, 125)
        chkExt03.Name = "chkExt03"
        chkExt03.Size = New Size(87, 27)
        chkExt03.TabIndex = 12
        chkExt03.Text = "Cheese"
        chkExt03.UseVisualStyleBackColor = True
        ' 
        ' chkExt02
        ' 
        chkExt02.AutoSize = True
        chkExt02.Font = New Font("Segoe UI", 10F)
        chkExt02.Location = New Point(12, 101)
        chkExt02.Name = "chkExt02"
        chkExt02.Size = New Size(109, 27)
        chkExt02.TabIndex = 11
        chkExt02.Text = "Anchovies"
        chkExt02.UseVisualStyleBackColor = True
        ' 
        ' chkExt01
        ' 
        chkExt01.AutoSize = True
        chkExt01.Font = New Font("Segoe UI", 10F)
        chkExt01.Location = New Point(12, 68)
        chkExt01.Name = "chkExt01"
        chkExt01.Size = New Size(136, 27)
        chkExt01.TabIndex = 10
        chkExt01.Text = "Green Pepper"
        chkExt01.UseVisualStyleBackColor = True
        ' 
        ' chkExt00
        ' 
        chkExt00.AutoSize = True
        chkExt00.Font = New Font("Segoe UI", 10F)
        chkExt00.Location = New Point(12, 45)
        chkExt00.Name = "chkExt00"
        chkExt00.Size = New Size(114, 27)
        chkExt00.TabIndex = 9
        chkExt00.Text = "Mashroom"
        chkExt00.UseVisualStyleBackColor = True
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 13F, FontStyle.Bold Or FontStyle.Underline)
        Label12.ForeColor = Color.Red
        Label12.Location = New Point(28, 5)
        Label12.Name = "Label12"
        Label12.Size = New Size(77, 30)
        Label12.TabIndex = 5
        Label12.Text = "Extras"
        ' 
        ' pnlBase
        ' 
        pnlBase.BackColor = Color.MidnightBlue
        pnlBase.Controls.Add(radbas02)
        pnlBase.Controls.Add(radBas01)
        pnlBase.Controls.Add(radBas00)
        pnlBase.Controls.Add(Label11)
        pnlBase.Location = New Point(234, 26)
        pnlBase.Name = "pnlBase"
        pnlBase.Size = New Size(169, 170)
        pnlBase.TabIndex = 1
        ' 
        ' radbas02
        ' 
        radbas02.AutoSize = True
        radbas02.Font = New Font("Segoe UI", 10F)
        radbas02.ForeColor = SystemColors.ButtonFace
        radbas02.Location = New Point(14, 111)
        radbas02.Name = "radbas02"
        radbas02.Size = New Size(120, 27)
        radbas02.TabIndex = 8
        radbas02.TabStop = True
        radbas02.Text = "35cm/14 in."
        radbas02.UseVisualStyleBackColor = True
        ' 
        ' radBas01
        ' 
        radBas01.AutoSize = True
        radBas01.Font = New Font("Segoe UI", 10F)
        radBas01.ForeColor = SystemColors.ButtonFace
        radBas01.Location = New Point(14, 78)
        radBas01.Name = "radBas01"
        radBas01.Size = New Size(120, 27)
        radBas01.TabIndex = 7
        radBas01.TabStop = True
        radBas01.Text = "30cm/12 in."
        radBas01.UseVisualStyleBackColor = True
        ' 
        ' radBas00
        ' 
        radBas00.AutoSize = True
        radBas00.Font = New Font("Segoe UI", 10F)
        radBas00.ForeColor = SystemColors.ButtonFace
        radBas00.Location = New Point(14, 48)
        radBas00.Name = "radBas00"
        radBas00.Size = New Size(120, 27)
        radBas00.TabIndex = 6
        radBas00.TabStop = True
        radBas00.Text = "25cm/10 in."
        radBas00.UseVisualStyleBackColor = True
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 13F, FontStyle.Bold Or FontStyle.Underline)
        Label11.ForeColor = Color.Red
        Label11.Location = New Point(25, 11)
        Label11.Name = "Label11"
        Label11.Size = New Size(61, 30)
        Label11.TabIndex = 5
        Label11.Text = "Base"
        ' 
        ' pnlTopping
        ' 
        pnlTopping.BackColor = Color.SeaGreen
        pnlTopping.Controls.Add(Label10)
        pnlTopping.Controls.Add(radTop02)
        pnlTopping.Controls.Add(radTop01)
        pnlTopping.Controls.Add(radTop00)
        pnlTopping.Location = New Point(32, 30)
        pnlTopping.Name = "pnlTopping"
        pnlTopping.Size = New Size(169, 170)
        pnlTopping.TabIndex = 0
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 13F, FontStyle.Bold Or FontStyle.Underline)
        Label10.ForeColor = Color.Red
        Label10.Location = New Point(25, 8)
        Label10.Name = "Label10"
        Label10.Size = New Size(98, 30)
        Label10.TabIndex = 4
        Label10.Text = "Topping"
        ' 
        ' radTop02
        ' 
        radTop02.AutoSize = True
        radTop02.Font = New Font("Segoe UI", 10F)
        radTop02.ForeColor = SystemColors.ButtonFace
        radTop02.Location = New Point(18, 111)
        radTop02.Name = "radTop02"
        radTop02.Size = New Size(114, 27)
        radTop02.TabIndex = 2
        radTop02.TabStop = True
        radTop02.Text = "Meat Feast"
        radTop02.UseVisualStyleBackColor = True
        ' 
        ' radTop01
        ' 
        radTop01.AutoSize = True
        radTop01.Font = New Font("Segoe UI", 10F)
        radTop01.ForeColor = SystemColors.ButtonFace
        radTop01.Location = New Point(18, 78)
        radTop01.Name = "radTop01"
        radTop01.Size = New Size(131, 27)
        radTop01.TabIndex = 1
        radTop01.TabStop = True
        radTop01.Text = "Four Seasons"
        radTop01.UseVisualStyleBackColor = True
        ' 
        ' radTop00
        ' 
        radTop00.AutoSize = True
        radTop00.Font = New Font("Segoe UI", 10F)
        radTop00.ForeColor = SystemColors.ButtonFace
        radTop00.Location = New Point(18, 45)
        radTop00.Name = "radTop00"
        radTop00.Size = New Size(115, 27)
        radTop00.TabIndex = 0
        radTop00.TabStop = True
        radTop00.Text = "Margherita"
        radTop00.UseVisualStyleBackColor = True
        ' 
        ' prtContinuation
        ' 
        ' 
        ' prtDeliveryNote
        ' 
        ' 
        ' dashboard
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1659, 889)
        Controls.Add(pnlRight)
        Controls.Add(pnlLeft)
        Controls.Add(Panel1)
        Controls.Add(cmdContinue)
        Controls.Add(txtTel)
        Controls.Add(Label2)
        ForeColor = SystemColors.ActiveCaptionText
        Name = "dashboard"
        Text = "dashboard"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        pnlLeft.ResumeLayout(False)
        pnlLeft.PerformLayout()
        pnlRight.ResumeLayout(False)
        pnlRight.PerformLayout()
        pnlDrinks.ResumeLayout(False)
        pnlDrinks.PerformLayout()
        CType(nudDrk03, ComponentModel.ISupportInitialize).EndInit()
        CType(nudDrk02, ComponentModel.ISupportInitialize).EndInit()
        CType(nudDrk01, ComponentModel.ISupportInitialize).EndInit()
        CType(nudDrk00, ComponentModel.ISupportInitialize).EndInit()
        pnlExtras.ResumeLayout(False)
        pnlExtras.PerformLayout()
        pnlBase.ResumeLayout(False)
        pnlBase.PerformLayout()
        pnlTopping.ResumeLayout(False)
        pnlTopping.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmdContinue As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents pnlLeft As Panel
    Friend WithEvents pnlRight As Panel
    Friend WithEvents pnlTopping As Panel
    Friend WithEvents pnlExtras As Panel
    Friend WithEvents pnlBase As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cmdSave As Button
    Friend WithEvents txtForename As TextBox
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents txtAddress01 As TextBox
    Friend WithEvents txtAddress02 As TextBox
    Friend WithEvents txtTown As TextBox
    Friend WithEvents txtPostcode As TextBox
    Friend WithEvents txtOrder As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents radTop02 As RadioButton
    Friend WithEvents radTop01 As RadioButton
    Friend WithEvents radTop00 As RadioButton
    Friend WithEvents Label12 As Label
    Friend WithEvents radBas00 As RadioButton
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents chkExt02 As CheckBox
    Friend WithEvents chkExt01 As CheckBox
    Friend WithEvents chkExt00 As CheckBox
    Friend WithEvents radbas02 As RadioButton
    Friend WithEvents radBas01 As RadioButton
    Friend WithEvents chkExt03 As CheckBox
    Friend WithEvents cmdAddItem As Button
    Friend WithEvents pnlDrinks As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents nudDrk00 As NumericUpDown
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents nudDrk03 As NumericUpDown
    Friend WithEvents nudDrk02 As NumericUpDown
    Friend WithEvents nudDrk01 As NumericUpDown
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblDeliveryCharge As Label
    Friend WithEvents lblOderValue As Label
    Friend WithEvents lblOderTotal As Label
    Friend WithEvents cmdClear As Button
    Friend WithEvents cmdPrint As Button
    Friend WithEvents prtContinuation As Printing.PrintDocument
    Friend WithEvents prtDeliveryNote As Printing.PrintDocument
    Public WithEvents txtTel As TextBox
    Friend WithEvents Button1 As Button
End Class
