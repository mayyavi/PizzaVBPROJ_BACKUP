﻿Imports System.Data.SqlClient

Public Class login

    '' LOGIN PAGE

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username = TextBox1.Text.Trim
        Dim password = TextBox2.Text.Trim

        Dim authResult As Integer = AuthenticateUser(username, password)

        If authResult = 0 Then
            MessageBox.Show("Login successful as Admin!")
            ' Open the admin form
            admin.Show()
            Me.Hide()
        ElseIf authResult = 2 Then
            MessageBox.Show("Login successful as User!")
            TextBox1.Clear()
            TextBox2.Clear()
            ' Open the user dashboard
            dashboard.Show()
            Me.Hide()
        Else
            MessageBox.Show("Invalid username or password. Please try again.")
        End If
    End Sub

    Private Function AuthenticateUser(username As String, password As String) As Integer
        Dim connectionString As String = "Data Source=DESKTOP-G9C6I8O\SQLEXPRESS;Initial Catalog=pizzadb;Integrated Security=True;"

        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim query As String = "SELECT IsAdmin FROM Users WHERE Username = @Username AND Password = @Password"
                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@Username", username)
                        command.Parameters.AddWithValue("@Password", password)

                        Dim result As Object = command.ExecuteScalar()
                        If result Is DBNull.Value Then
                            Return 2
                        End If

                        If result IsNot Nothing AndAlso result IsNot DBNull.Value Then
                            ' The query returned a valid result
                            If result = 1 Then
                                Return 0 ' Admin user

                            End If
                        Else
                            ' The query didn't return a valid result, indicating invalid credentials
                            Return 1 ' Invalid credentials
                        End If
                    End Using
                Else
                    MessageBox.Show("Unable to open database connection.")
                    Return 1 ' Invalid credentials
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
            Return 1 ' Invalid credentials
        End Try
    End Function




    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Register.Show()
        Me.Hide()
    End Sub
End Class
