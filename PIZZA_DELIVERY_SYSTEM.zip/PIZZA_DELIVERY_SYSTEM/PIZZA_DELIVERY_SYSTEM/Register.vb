﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Register

    '' REGISTER PAGE

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Registration functionality
        Dim username = TextBox1.Text
        Dim password = TextBox2.Text

        If RegisterUser(username, password) Then
            MessageBox.Show("Registration successful!")
        Else
            MessageBox.Show("Registration failed. Please try again.")
        End If
    End Sub

    Private Function RegisterUser(username As String, password As String) As Boolean
        Dim connectionString As String = "Data Source=DESKTOP-G9C6I8O\SQLEXPRESS;Initial Catalog=pizzadb;Integrated Security=True;"

        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                If connection.State = ConnectionState.Open Then
                    Dim query As String = "INSERT INTO Users (Username, Password) VALUES (@Username, @Password)"
                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@Username", username)
                        command.Parameters.AddWithValue("@Password", password)

                        Dim rowsAffected As Integer = command.ExecuteNonQuery()
                        Return rowsAffected > 0
                    End Using
                Else
                    MessageBox.Show("Unable to open database connection.")
                    Return False
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
            Return False
        End Try
    End Function



    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click
        login.Show()
        Me.Hide()
    End Sub
End Class
